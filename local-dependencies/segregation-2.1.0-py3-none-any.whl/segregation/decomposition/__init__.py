from .decompose_segregation import *
